document.addEventListener("DOMContentLoaded", () => {
  // Año automático del pie de página
  const year = document.querySelector(".footer small");
  if (year) year.textContent = `© ${new Date().getFullYear()} Sstyle Clothing`;

  // Botones de catálogo
  document.querySelectorAll(".add-cart").forEach(button => {
    button.addEventListener("click", () => {
      const product = button.dataset.product;
      button.textContent = "¡Agregado!";
      button.classList.remove("btn-dark");
      button.classList.add("btn-success");

      setTimeout(() => {
        button.textContent = "Agregar";
        button.classList.remove("btn-success");
        button.classList.add("btn-dark");
      }, 1500);

      alert(`${product} fue agregado a tu selección.`);
    });
  });

  // Formularios demostrativos para el proyecto académico
  document.getElementById("contactForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("¡Gracias! Tu mensaje fue enviado correctamente.");
    e.target.reset();
  });

  document.getElementById("loginForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Inicio de sesión de demostración. Conecta este formulario a una base de datos para hacerlo funcional.");
  });

  document.getElementById("registerForm")?.addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Registro de demostración realizado correctamente.");
    e.target.reset();
  });
});
