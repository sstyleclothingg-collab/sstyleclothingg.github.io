SSTYLE CLOTHING - PROYECTO WEB
=================================

Contenido:
- index.html
- css/estilos.css
- js/script.js
- img/ (5 fotografías proporcionadas)

Requisitos cubiertos:
- HTML: hipervínculos, imágenes, listas, tabla, formularios y video.
- CSS externo.
- Bootstrap.
- Carrusel de imágenes.
- Catálogo de productos.
- Inicio de sesión y registro (demostrativos).
- Formulario de contacto.
- Video de YouTube incrustado.
- Navegación interna entre secciones.

IMPORTANTE:
Los formularios funcionan como demostración visual. Para almacenar usuarios,
inicios de sesión o mensajes realmente se necesita un backend/base de datos.

VIDEO:
Se utilizó un video público de YouTube de temática streetwear:
Streetwear Lookbook | clothesnbits
https://www.youtube.com/watch?v=U4V1EN7KVQU

REDES:
Instagram: https://www.instagram.com/sstyle.clothing/

Para abrir:
1. Descomprime la carpeta.
2. Abre index.html en Chrome/Edge.
3. Necesitas conexión a Internet para Bootstrap, Google Fonts y el video de YouTube.
